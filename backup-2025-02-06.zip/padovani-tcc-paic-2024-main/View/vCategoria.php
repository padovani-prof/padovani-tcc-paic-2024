<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Formulario-Categoia</title>
</head>
<body>
  <header>
      <h1>Categoria</h1>
  </header>

  <section>
      <table border="1">
          <tr>
            <th>Nome</th>
            <th>Alterar</th>
            <th>Apagar</th>
          </tr>
              {{Categoria}}
            
      </table>

    <a href="cFormularioCategoria.php"><input type="button" value="Nova Categoria"></a> 
    <a href="cMenu.php"><input type="button" value="Voltar"></a>
  </section>



  
</body>
</html>