<?php 
// configuração do banco para todos os Model
$servidor = 'localhost'; 
$usuario = 'root';
$senha = '';
$banco = 'sgrp';

?>